namespace NodeJS {
	interface ProcessEnv {
		DB_URL: string;
		PORT: Number;
	}
}
